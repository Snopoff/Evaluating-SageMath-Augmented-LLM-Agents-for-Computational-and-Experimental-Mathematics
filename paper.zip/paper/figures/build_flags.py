from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=Path(__file__).resolve().parent
plt.rcParams.update({'font.size':10,'pdf.fonttype':42,'svg.fonttype':'none'})
fig,ax=plt.subplots(figsize=(6.4,1.25))
vals=[84,10,29,13]; labels=['theorem','lemma','def / abbrev','unmatched'];colors=['#264b6c','#688eaa','#d4a246','#b96353']
left=0
for v,l,c in zip(vals,labels,colors):
 ax.barh(0,v,left=left,color=c,height=.45,label=l)
 ax.text(left+v/2,0,str(v),ha='center',va='center',color='white' if l!='def / abbrev' else '#222',weight='bold')
 left+=v
ax.set_xlim(0,136);ax.set_ylim(-.35,.35);ax.set_yticks([]);ax.set_xticks([])
for s in ax.spines.values():s.set_visible(False)
ax.legend(ncol=4,loc='lower center',bbox_to_anchor=(.5,-.52),frameon=False,handlelength=1)
fig.subplots_adjust(left=.01,right=.99,top=.96,bottom=.40)
for ext in ['pdf','svg','png']:fig.savefig(p/f'intermediate-flags.{ext}',dpi=180)
