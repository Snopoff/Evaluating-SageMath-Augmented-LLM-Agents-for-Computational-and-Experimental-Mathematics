# Prompt for GPT-6 Astra — 4-page workshop paper draft (LaTeX project)

Copy everything below the line into GPT-6 Astra.

---

You are drafting a **4-page workshop paper** (excluding references and appendix) for
**The 6th Workshop on Mathematical Reasoning and AI**. Deliver a complete, compilable
LaTeX project, not prose in a chat window.

## 1. What the paper is about

We ran a two-stage pipeline on research-level mathematics questions drawn from arXiv
papers. Stage one (a "Sage agent", Claude Opus 4.8 with a SageMath tool) produced a
candidate answer and a final natural-language explanation. Stage two (a "Lean agent",
Claude Opus 5 with a stateless Lean 4 + Mathlib execution tool) received the question and
the stage-one answer **blind** — no ground truth, no correctness label, and none of the
Sage agent's intermediate code or output — and tried either to prove the candidate answer
or to refute it, writing its own Lean definitions as needed. It returned PROVED, REFUTED,
or UNKNOWN.

The motivating question is whether a proof-assistant stage can serve as a *verifier* for
computational answers — the role usually played by LLM-as-a-judge or by a symbolic
equality checker.

**The honest answer this run supports is: not yet, and the interesting content is in
exactly why not.** The paper is a negative-to-mixed result plus a measurement-methodology
contribution. Do not write it as a success story, and do not pad it into one.

The paper's real contributions, in priority order:

1. **A semantic taxonomy of what a "PROVED" actually certifies.** Kernel-checked ≠ the
   original theorem. We found *surrogate proofs*: formally valid Lean developments that
   prove a related-but-different statement and still return PROVED.
2. **A measurement defect that inflates apparent proof counts**, found and reproduced
   locally in our own runtime — a class of bug any similar pipeline can have.
3. **A taxonomy of UNKNOWN**, showing that a single refusal label hides everything from
   "no formal statement was ever written" to "substantial components proved, final
   assembly missing."
4. **Honest interval-based reporting** on a partial run, showing that at this sample size
   the label slices do not separate at all — and that the labels being compared are not
   even drawn from one process (see §3).

## 2. Hard constraints on truthfulness

This is the most important section of this prompt. The underlying run is **partial and
small**. Every quantitative claim you write must be traceable to the fact sheet in §4.

- **Invent no numbers.** If you want a statistic that is not in §4, write
  `\todo{need: <description>}` in the LaTeX and list it in `OPEN_QUESTIONS.md`. Do not
  interpolate, do not round into a nicer story, do not reconstruct a number you think
  "must" follow.
- **Report proportions with Wilson 95% intervals**, never bare point estimates. The
  subgroup counts are as small as n=14. Where an interval is given in §4, use it.
- **No causal language.** There was no control condition without the Sage answer, so the
  causal contribution of the stage-one hint is *not measured*. Never write that Sage
  "helps", "improves", or "boosts" anything.
- **Do not claim the 57 formalizations were audited for translation fidelity.** They were
  not. The semantic categories are the analyst's preliminary reading of code and text.
  Say so explicitly in the paper, not only in a footnote.
- **Do not claim the source papers were re-verified.** They were not. Where the pipeline
  contradicts a paper's stated answer, the paper is not thereby refuted — the discrepancy
  may lie in the question, the answer normalization, or the formalization.
- **Cost is an estimate, not an invoice.** Say "estimated at standard rates"; never
  "we spent".
- **The completed subset is not a random sample.** The run stopped on account-balance
  exhaustion mid-flight with four agents in parallel, so which tasks completed depends on
  ordering and per-task duration. No proportion may be extrapolated to the full 133, and
  certainly not to "research mathematics."

## 3. The framing correction you must apply

The internal report this is based on has a flaw. Do not inherit it.

That report speaks throughout of a single "judge label". In fact the label is produced by a
**two-stage cascade**, verified in `src/benchmark/judge_sympy_answers.py`:

1. A symbolic equality checker runs first. If it returns True, that *is* the label and
   `label_source = symbolic_checker`. The LLM judge is never consulted.
2. Only if the symbolic checker returns False is the LLM judge invoked, and its majority
   vote becomes the label with `label_source = llm_judge_majority`.

Three consequences the paper must reflect:

- `symbolic_checker` labels are **positive by construction** — 63 of 133, all positive.
  There is no such thing as a symbolic-checker negative in this data.
- `llm_judge_majority` covers 70 of 133 (35 positive / 35 negative) and is a **selected,
  harder subset**: every item in it is one where symbolic equality already *failed*. The
  upstream pipeline itself flags these as `contested`.
- Therefore a judge-*positive* item means "the checker said no and the judge overruled it
  to yes" — i.e. precisely the answers that are correct but not symbolically identical to
  the reference: different normal form, different presentation, or a genuinely ambiguous
  answer specification. These are exactly the cases where formalization is hardest, and
  where our `ambiguous` category lives.

This is very likely the mechanism behind the direction reversal in the numbers below, and
it is a more interesting observation than the reversal itself: **the subgroup where a
proof assistant would be most valuable as a judge replacement is also the subgroup where
it most often returns UNKNOWN.** State it as a hypothesis consistent with the data, not as
a demonstrated effect — n is far too small to establish it.

A raw "positive vs negative" comparison therefore compares a mixture (checker-positive +
overruled-contested) against a pure contested-negative slice. The paper must present the
three-way split (checker-positive / judge-positive / judge-negative), and may present the
pooled two-way version only as the naive comparison it is arguing against.

Note also: case 00165, described in the internal report as "the judge agreed with an
answer that is wrong for this text", was in fact labelled by the **symbolic checker**.
Describe it correctly.

## 4. Verified fact sheet

Every number below is verified against the run artifacts. Use these and only these.

### Run and dataset
- Task family `opus-4-8`; 133 unique question IDs, each appearing once; protocol
  `sage-lean-v1`; Lean agent is Claude Opus 5 via the Anthropic API.
- Dataset shuffled with a fixed seed; 4 agents in parallel; run halted by account-balance
  exhaustion.
- 57 tasks completed; 76 never produced a result.
- The raw JSONL holds 235 records: 57 completions and 178 error records across two launch
  attempts. Errors are deduplicated by ID. **235 records ≠ 235 tasks** — a trap worth one
  sentence in the paper, since it is exactly the kind of thing that silently inflates a
  reported denominator.
- Answer types across the 133: 73 `expression`, 60 `number`.
- Top arXiv categories across the 133: math.NT 25, math.CO 21, math.AG 13, math.GT 12,
  math.AP 9, math.PR 9.
- Source snapshots pinned by SHA-256:
  results `177b0a4de6bc5bcf85796b4fc153d7d2130ebb04686681facaddd4d3295981ad`,
  tasks `f03f3501d28c0fba91881943deafb7a24309cabafa57a4b271bfd19fad7a5951`.

### Outcomes on the 57 completed
- 7 PROVED, 3 REFUTED, 47 UNKNOWN.
- 10 decisive verdicts (PROVED or REFUTED): 17.5% of completed, 95% CI [10, 29];
  7.5% of the 133 planned.
- **All 10 final certificates were re-checked locally** during the audit (independent
  replay, `import Mathlib`, typed final wrapper). All 10 replayed successfully.

### Label slices — pooled (the naive view)
| slice | completed / selected | PROVED | REFUTED | UNKNOWN | API error | PROVED rate, 95% CI |
|---|---|---|---|---|---|---|
| label positive | 42 / 98 | 5 | 1 | 36 | 56 | 11.9%, [5, 25] |
| label negative | 15 / 35 | 2 | 2 | 11 | 20 | 13.3%, [4, 38] |
| total | 57 / 133 | 7 | 3 | 47 | 76 | 12.3%, [6, 23] |

The two intervals overlap almost entirely: **at this sample size the label does not
predict the Lean outcome in either direction.**

### Label slices — by provenance (the view the paper should lead with)
Among the 57 completed: 28 `symbolic_checker` (all positive), 14 `llm_judge_majority`
positive, 15 `llm_judge_majority` negative. Recall from §3 that both judge slices are
items the symbolic checker had already rejected.

| slice | n | PROVED | decisive | decisive rate, 95% CI |
|---|---|---|---|---|
| symbolic_checker (all positive) | 28 | 4 | 5 | 17.9%, [8, 36] |
| llm_judge positive | 14 | 1 | 1 | 7.1%, [1, 31] |
| llm_judge negative | 15 | 2 | 4 | 26.7%, [11, 52] |

Within the LLM-judge subset the *nominal* direction is the opposite of the naive
expectation — the judge-negative slice yields more decisive verdicts. **The intervals
overlap heavily and n is tiny; present this as a caution against reading the pooled table,
not as a finding.**

### Agreement between decisive verdicts and labels
7 of the 10 decisive verdicts agreed with the label. Wilson 95% CI for 7/10 is
[40%, 89%], which contains 50%. **Do not report "70% accuracy".** Three conflicts: one
REFUTED against a positive label, two PROVED against negative labels.

### Semantic taxonomy of the 57 (preliminary analyst judgment, not expert audit)
| category | n | meaning |
|---|---|---|
| full | 3 | general result, candidate for acceptance |
| counterexample | 2 | substantive counterexample found by the Lean agent |
| surrogate | 3 | related object / unclosed reduction to the original |
| ambiguous | 2 | answer-specification problem |
| assembly | 2 | substantial components, no final assembly |
| partial | 4 | meaningful subclass / part of a proof |
| instances | 5 | specific instances only |
| support | 19 | auxiliary lemma / sanity check |
| computation | 1 | computational barrier |
| blocked | 16 | goal not proved; definitions / search / scaffolding |

### The 10 decisive cases (id, verdict, label, label source, category)
- 00508 PROVED, positive, symbolic_checker, **full** — idempotents of a small Schröder
  monoid; partial maps modelled as `Fin n → Option (Fin n)`; monotonicity, decrease and
  idempotency checked; bijection with three-coloured words gives |E(SSₙ)| = 3ⁿ⁻¹ for all
  n ≥ 1.
- 00055 PROVED, positive, symbolic_checker, **full** — unique modular continuation;
  recursive approximations, stabilization and uniqueness; constructive general result;
  the formal version explicitly assumes n ≥ 1.
- 00066 PROVED, positive, symbolic_checker, **full** — invariant functional on C(ℤ_p, K);
  uses existing Mahler-series results to prove surjectivity of the difference operator.
  Open: whether the normed model K matches the intended complete extension of ℚ_p.
- 00080 REFUTED, negative, llm_judge_majority, **counterexample** — an *additional* triple
  (2−√3, (√3−1)/2, (√3−1)/2) with continued-fraction constraints, sum, ordering and
  irrationality all checked. Refutes the *completeness* of the Sage answer. The
  counterexample was **not** present in the explanation passed to the Lean agent.
- 00165 REFUTED, positive, **symbolic_checker**, **counterexample** — with c = 2⁶·5⁵·3⁵ and
  z = 1, the triple (30,30,1) is primitive under the literal gcd(x,y,z)=1 as written, and
  30⁵ + 30⁵ = 48 600 000. The answer "0" fails a literal reading. This does not refute the
  source paper; it exposes a question/normalization mismatch.
- 00157 PROVED, negative, llm_judge_majority, **surrogate** — stable upper genus of
  PSL₂(23). Existence of a group action on a surface was replaced by satisfaction of the
  Riemann–Hurwitz formula. The arithmetic condition is proved; realizability of signatures
  is not. PROVED does not certify the original genus.
- 00151 PROVED, positive, symbolic_checker, **surrogate** — minimal dilatation and two
  matrices; algebra proved without the full reduction to the original object.
- 00532 PROVED, positive, symbolic_checker, **surrogate** — lambda lengths and the Plücker
  identity; same pattern.
- 00007 PROVED, negative, llm_judge_majority, **ambiguous** — connected edge covers of
  five explicit graphs. The enumeration is real, but G₃/G₄ are transposed relative to the
  source answer and correspondence to the paper's figures was never established. The
  resulting tuple does not match the reference.
- 00109 REFUTED, negative, llm_judge_majority, **ambiguous** — the Sage explanation gives
  the *beginning* of a q-series and explicitly says there is no closed form; the
  normalized field contains a finite polynomial. Lean correctly proves the q²⁷ coefficient
  is nonzero and returns REFUTED. Correct refutation of the polynomial equality; contested
  reading of the original answer.

### The measurement defect (contribution 2)
In `src/lean/runtime.py`, the result of `#print axioms` is tested for non-empty text, but
its *error* text is not propagated. Querying a declaration name that does not exist yields
an error message which the parser turns into an empty axiom list, i.e. "no axioms used",
i.e. proved. Reproduced locally:

```
code      = "example : True := trivial"
decl_name = "nonexistent_audit_probe"
→ status="ok", proved=True     # no declaration with that name exists
```

Also, an axiom check on a data definition such as `def audit_number : Nat := 42` returns
`proved=True`. That is a legitimate declaration but not a proved theorem.

Consequences across all saved tool calls: **136 positive intermediate `proved` flags**, of
which theorem 84, lemma 10, `def`/`abbrev` 29, and 13 where no declaration with the
requested name appears in the submitted code at all. At least one such flag appears in
**39 of the 47 UNKNOWN** tasks, and **8 of those 39 carry no flag on a `theorem` or
`lemma` at all**. Therefore the count of positive intermediate flags is *not* a count of
proved lemmas, and any pipeline reporting "lemmas proved" from a similar signal is
reporting an inflated number.

Two framings worth making explicitly, because they generalize beyond our code:
(a) an axiom-tracking check is a check on a *named declaration*, so it must fail closed
when the name is absent; (b) "no axioms" is not "is a theorem" — it must be conjoined with
a check that the declaration is a proposition.

The runtime was **not modified** during the audit; the historical run is reported as it
happened. The 10 final certificates are unaffected: they carry a named certificate and a
typed wrapper and were re-checked independently.

### Self-reported failure reasons among the 47 UNKNOWN
`proof-search` 27, `missing-concept` 17, `timeout` 1, field empty 2. These are the agent's
own words in a free-text field — a self-report, not a diagnosis. Phrases like "not in
Mathlib" reflect the agent's bounded search; they do not establish that no equivalent
construction exists or could be defined.

### Effort and cost
- Turn counts: PROVED mean 9.9 / median 11; REFUTED mean 4.3 / median 4; UNKNOWN mean 6.4
  / median 5. Turn cap 12 (finalization can still appear at turn 13, so the cap binds).
- Lean tool calls per task: PROVED 8.9, REFUTED 3.3, UNKNOWN 5.1 (means).
- Median wall-clock per attempt: PROVED 403 s, REFUTED 294 s, UNKNOWN 175 s.
- Tokens over completed attempts: 10,869,322 input, 1,471,655 output.
- Estimated at standard Opus 5 rates ($5/M input, $25/M output, checked 2026-09-06):
  **$91.14 total**; PROVED $15.35, REFUTED $3.97, UNKNOWN $71.82 (78.8% of the total).
- UNKNOWN median $0.80, max $10.73 (task 00580, a quandle-ring quotient — the most
  expensive refusal, and one containing substantial algebraic components).
- Caching is not broken out in the aggregated fields, and error records carry no
  `token_usage`, so tokens burned before a failure are absent from this estimate.
  Interrupted attempts and any discounts move the figure in both directions.

The point to make from cost is **not** "refusals are expensive". It is that *cost per
refusal is uninformative*: the most expensive UNKNOWNs contain the most mathematical work,
while cheap ones are name searches. An optimization target should be cost per
full-or-partial result, not mean cost per UNKNOWN.

### What this run does and does not support
Supported:
- The pipeline can produce general, parametric Lean proofs, not only numeric spot checks.
- It can find a counterexample that was absent from the material it was given, and verify
  that counterexample's side conditions.
- A surrogate proof can pass the kernel and be reported as PROVED without resolving the
  original problem.
- UNKNOWN is heterogeneous, from "no statement written" to "substantial parts proved".
- Answer normalization and question-statement precision are error sources independent of
  the Lean kernel.
- The evaluation labels this pipeline is measured against are themselves produced by a
  cascade, so "agreement with the label" is not a single well-defined quantity.

Not supported (state these as explicit non-claims):
- "Lean replaces LLM-as-a-judge" — no separation by label at this n, and the semantic
  audit is incomplete.
- "All 7 PROVED are proved original theorems" — 3 are surrogates and 1 needs a
  graph-labelling check.
- "Sage improves the probability of a proof" — no no-hint control condition exists.
- "47 tasks are mathematically inaccessible" — what was tested is one model, one budget,
  one library, one prompt.
- "$91.14 is the account's actual spend."

## 5. Deliverable

Produce a LaTeX project with this structure:

```
paper/
  main.tex              % \documentclass, packages, \input of each section
  sections/00_abstract.tex
  sections/01_intro.tex
  sections/02_setup.tex
  sections/03_results.tex
  sections/04_failure_modes.tex
  sections/05_cost.tex
  sections/06_limitations.tex
  sections/07_conclusion.tex
  appendix/A_case_studies.tex     % overflow beyond the 4 pages
  tables/outcomes.tex             % the provenance-split table
  tables/taxonomy.tex             % the semantic taxonomy
  refs.bib
  figures/                        % see below
  README.md                       % how to build; what is still a placeholder
  OPEN_QUESTIONS.md               % every \todo, collected, with what is needed to close it
  Makefile                        % `make` -> latexmk -pdf main.tex; `make clean`
```

Requirements:

- **Page budget is 4 pages excluding references.** This is the binding constraint. Cut
  ruthlessly; push case studies and secondary tables to the appendix. Do not shrink
  margins, do not use `\vspace{-…}` hacks, do not drop below the style's default font size.
- **Style file.** I have not verified this workshop's template. Write `main.tex` against
  the NeurIPS-style workshop template as a *placeholder*, isolate every venue-specific
  choice (documentclass, style file, anonymity, line numbers) into a clearly commented
  block at the top of `main.tex`, and note in `README.md` that this block must be swapped
  for the official style file before submission. **Do not invent a template URL, a
  deadline, a page-limit rule, or a citation style you have not been given.**
- Two figures at most in the body. Recommended: (1) the provenance-split outcome chart —
  note that our existing `label-outcomes` figure uses the *pooled* two-way split and is
  therefore superseded by §3, so specify the corrected figure in `OPEN_QUESTIONS.md` rather
  than reusing the old one; (2) the composition of the 136 intermediate `proved` flags,
  which carries contribution 2 in one image. Reference figures as `figures/<name>.pdf`
  and record in `README.md` that PNG/SVG sources exist and need converting.
- Tables in `booktabs`, `siunitx` for aligned numerics, intervals typeset consistently.
- Every claim in the body that rests on a number in §4 should be checkable against
  `tables/`. Prefer one honest table to three decorative ones.
- Write in the past tense about what was run, present tense about what the data shows.
  No hedging adverbs stacked on hedged claims — state the limitation once, plainly, and
  move on.

## 6. Title and abstract

Propose 3 candidate titles at the top of `README.md` and use your preferred one. The title
should signal the mixed/negative result honestly. Avoid "Towards…" and avoid implying a
solved verification pipeline. The abstract must contain: the sample size and its
partiality, the decisive-verdict rate with its interval, the surrogate-proof finding, and
the measurement-defect finding.

## 7. Before you finish

Add to `OPEN_QUESTIONS.md`, at minimum:
- the corrected provenance-split figure (does not yet exist),
- whether an expert has reviewed the 3 `full` candidates and 2 counterexamples,
- the missing no-hint control condition,
- the exact venue template and anonymity requirement,
- any `\todo` you emitted.

Then state, in your reply outside the files, which parts of the paper are load-bearing
claims you took directly from §4 and which are your own framing — so those can be checked
separately.
