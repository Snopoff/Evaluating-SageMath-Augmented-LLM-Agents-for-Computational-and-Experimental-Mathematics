# Verified literature added to the workshop paper

Checked 2026-09-06 against primary arXiv records and ACL Anthology. Claims added to the body are qualitative positioning, not new experimental numbers. ArXiv entries use their initial preprint year; publication venues are not inferred. All entries below are cited in the body and contain clickable URLs in the compiled bibliography.

| BibTeX key | Primary source | Role in this manuscript |
|---|---|---|
| snopov2026sage | [Snopov and Magai: Evaluating SageMath-Augmented LLM Agents for Computational and Experimental Mathematics](https://arxiv.org/abs/2607.06820) | The preceding SageMath study and source of the computational pipeline; cited in introduction and setup. This is the public paper, not the differently titled local AAAI revision. |
| zhang2025realmath | [Zhang, Petrui, Nikolić, and Tramèr: RealMath](https://arxiv.org/abs/2505.12575) | Attribution for the upstream research-derived benchmark. Author names verified from the primary record rather than copied from the older local bibliography. |
| wu2022autoformalization | [Wu et al.: Autoformalization with Large Language Models](https://arxiv.org/abs/2205.12615) | Foundational natural-language-to-formal-statement work. |
| azerbayev2023proofnet | [Azerbayev et al.: ProofNet](https://arxiv.org/abs/2302.12433) | Benchmark joining informal statements/proofs and formal statements. |
| yang2023leandojo | [Yang et al.: LeanDojo](https://arxiv.org/abs/2306.15626) | Proof search and premise retrieval for already formal targets. |
| lu2024formalalign | [Lu et al.: FormalAlign](https://arxiv.org/abs/2410.10135) | Prior work explicitly evaluating informal/formal semantic alignment. |
| poiroux2025reliable | [Poiroux et al.: Reliable Evaluation and Benchmarks for Statement Autoformalization](https://aclanthology.org/2025.emnlp-main.907/) | BEq+, ProofNetVerif, and semantic evaluation beyond compilation; ACL metadata supplies exact authors, pages, DOI, and venue. |
| gui2026robustness | [Gui, Yang, and Shi: Evaluating the Robustness of Proof Autoformalization in Lean 4](https://arxiv.org/abs/2606.14867) | Fidelity under paraphrases and local perturbations of informal proofs. |
| moakhar2026beyond | [Soltani Moakhar et al.: Beyond the Library](https://arxiv.org/abs/2606.31134) | Research-level autoformalization with new definitions, auxiliary-lemma validation, and human expert review. |

The existing Lean documentation and mathlib references remain. The paper does not claim that the semantic-fidelity problem is new; its contribution is a case-level analysis of this pipeline, including surrogate verdicts, normalization, label provenance, and runtime measurement defects. No results from the broader SageMath experiment are imported into the partial Lean run.
