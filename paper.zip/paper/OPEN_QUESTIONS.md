# Open questions before submission

## Required substantive checks

- **Expert review of three `full` candidates and two counterexamples.** No expert translation-fidelity audit is established by this draft. Obtain named reviews of 00508, 00055, 00066, 00080, and 00165 against the question and source assumptions. Record assumptions, quantifiers, object correspondence, and remaining reductions. In particular: the n >= 1 domain in 00055; the normed model of K in 00066; and the meaning of “primitive” in 00165. Source papers have not been re-verified.
- **Missing no-hint control.** It was not run. A causal claim about Sage requires paired conditions with/without the answer and explanation, matched resources, and prespecified outcome assessment. Until then, retain the explicit non-claim.
- **Cascade interpretation.** Verify any proposed explanation of the judge-positive slice through case-level annotation of normalization/presentation issues. Symbolic rejection followed by judge acceptance does not establish correctness. Current subgroup intervals overlap and do not demonstrate an effect or equivalence.
- **Surrogate and ambiguous cases.** Independent review is needed for the arithmetic-to-action reduction in 00157, geometry correspondences in 00151/00532, graph identities in 00007, and finite-polynomial versus series-prefix interpretation in 00109.

## Figure specified but not produced

- **Corrected provenance-split outcome figure.** The old report's pooled `label-outcomes` PNG/SVG must not be reused. Optional new filename: `figures/provenance-outcomes.pdf`. Show three rows: checker-positive (n=28, PROVED=4, decisive=5; 17.9%, Wilson [8,36]); LLM-positive (n=14, PROVED=1, decisive=1; 7.1%, [1,31]); LLM-negative (n=15, PROVED=2, decisive=4; 26.7%, [11,52]). Use a decisive-rate point/interval chart with count labels; explicitly mark both LLM rows as selected after symbolic rejection. Do not infer additional category counts for a stacked chart from subtraction. Export vector PDF from new SVG or plotting source. `tables/outcomes.tex` already supplies this information without needing a second figure. Recheck the four-page budget if inserted.

## Venue and editorial placeholders

- **Workshop template (verified, not yet applied).** The MATH-AI 2026 CFP requires
  `\usepackage[dblblindworkshop]{neurips_2026}`; 4 content pages, unlimited references and
  appendices; double-blind; deadline 6 September 2026 AoE; non-archival. `neurips_2026.sty`
  still needs to be fetched from
  <https://mathai-2026.github.io/files/mathai_neurips2026_template.zip> and swapped into the
  venue block at the top of `main.tex`. Confirm the bibliography style against the template.
- **Authors and affiliations.** Review is double-blind, so “Anonymous authors” stays for
  submission; supply names for the camera-ready version.
- **Related work (addressed in this revision).** The body now cites the preceding SageMath paper, RealMath, LLM autoformalization, ProofNet, LeanDojo, FormalAlign, BEq+, proof-perturbation fidelity, and research-level definition validation. Primary sources and the role of each citation are recorded in `LITERATURE_SOURCES.md`. These methods were not run as baselines; no comparative performance claim is made.

- **Statistical reference.** Add a verified primary reference for the Wilson method if required by the final citation policy. The present intervals are copied from the supplied fact sheet, not recomputed.

## Reproducibility and measurement follow-up

- **Environment and configuration details.** Supply the precise Lean/Mathlib revisions, provider model identifier, exact shuffle seed, inference settings, and complete prompts from a frozen manifest. The draft names only values supplied in the fact sheet.
- **Public artifact location.** Decide on an anonymized release and persistent link for logs, tasks, typed replay certificates, probes, and annotations. Current snapshot hashes identify local files; no public dataset URL is invented.
- **Cost accounting.** Preserve the estimate qualification. A billing reconciliation would need cache-resolved usage, interrupted-call accounting, and actual discounts; these are absent. The standard rates and verification date here come from the fact sheet.
- **Runtime remediation is future work.** Require successful name resolution, a proposition-valued declaration type, an explicit axiom policy, and a typed certificate for the intended target. The historical runtime was not modified during the audit. The figure's syntax groups are diagnostics, not semantic declaration-type checks.
- **UNKNOWN assessment.** The taxonomy is preliminary. Establish an annotation rubric and expert agreement before treating partial-work categories as validated outcomes or optimizing cost per category.

## Inline TODO inventory

There are no inline `\todo{...}` invocations in the manuscript. The `\todo` command is defined for later edits. All unresolved matters above are disclosed in prose or documented here; no missing number has been filled in by reconstruction.
