# AAAI-27 Revision Notes

## What changed

- Reconstructed a clean manuscript source from the submitted PDF because the attached
  `CameraReady2027.tex` is the AAAI author-kit example, not the paper source.
- Reframed the paper around one supported claim: the complete
  SageMath-plus-documentation agent configuration improves exact-answer performance
  on a curated CAS-relevant subset, with heterogeneous gains across models.
- Made the study internally consistent at 20 configurations, 133 problems, two
  conditions, and 5,320 evaluations.
- Replaced unpaired Wilson-only comparisons with paired problem-bootstrap intervals
  and exact McNemar statistics.
- Replaced the token scatter with a paired performance figure.
- Recomputed all answer-type results from the 20-model data. Contrary to the older
  15-model narrative, mean gains are nearly identical for expression and numerical
  answers.
- Recomputed behavioral associations. Budget exhaustion has a moderate negative
  association with agent solve rate (Spearman rho = -0.41); immediate next-call
  recovery after an execution error has little association (rho = 0.12).
- Added a symbolic-only scorer sensitivity analysis. The mean gain remains positive
  but falls from 8.2 to 2.6 percentage points.
- Removed the case study, token-efficiency ranking, model-family speculation,
  conjecture-discovery claim, numbered "Findings," and missing appendix references.
- Removed the unsupported statement that 15% of routed cases received a human audit.
- Reduced the compiled paper from ten pages with technical material through page nine
  to five pages total, with no unresolved references.

## Files

- `aaai27_revised.tex`: revised manuscript.
- `references.bib`: compact bibliography used by the revision.
- `figures/paired_performance.pdf`: primary paired-result figure.
- `figures/tool_behavior.pdf`: behavioral analysis figure.
- `analysis/paired_model_statistics.csv`: per-model paired outcomes, bootstrap
  intervals, McNemar tests, and behavioral summaries.
- `analysis/summary.json`: aggregate statistics used in the text.
- `../scripts/paper_revision_analysis.py`: deterministic analysis and figure generator.

## Remaining submission risks

1. **Human validation:** no independently labeled audit is present in the repo.
   Completing a blinded, stratified audit of the judge-routed cases is the
   highest-value remaining empirical improvement.
2. **Judge-artifact alignment:** aggregate results and some per-run judge files reflect
   different normalization stages. Freeze one canonical result file and regenerate
   matching per-case judge records before claiming self-family judge sensitivity.
3. **Experiment metadata:** add exact provider model IDs, access dates, inference
   parameters, and retry policies from the run logs.
4. **Sage image:** confirm that the evaluated image was SageMath 10.5 and record its
   immutable container digest; the current repo default uses a mutable `latest` tag.
5. **Dataset construction:** record the final category-balancing rule or seed and
   document an explicit answer-leakage audit for contextualized questions.
6. **Anonymous artifact:** ensure the supplement, repository snapshot, traces, and
   file metadata contain no author identities.

## Reproduce the statistics

```bash
uv run --extra analysis python scripts/paper_revision_analysis.py
```

## Compile

From the `paper` directory, point TeX and BibTeX to the supplied AAAI-27 author kit:

```bash
TEXINPUTS=/path/to/AuthorKit27: \
BSTINPUTS=/path/to/AuthorKit27: \
latexmk -pdf -interaction=nonstopmode -halt-on-error aaai27_revised.tex
```
