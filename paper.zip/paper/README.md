# Title

**Proving the Answer: Sage-to-Lean Verification of Agent-Proposed Mathematics** (used)

Alternatives considered: "Can a Lean Agent Adjudicate Computer-Algebra Answers?";
"Kernel-Checked, Question-Unresolved: Failure Modes in Sage-to-Lean Verification".

## Build

Run `make` in this directory. It invokes `latexmk -pdf main.tex` and runs BibTeX as needed. `make clean` removes auxiliary build files while retaining the PDF. Requires a TeX distribution with latexmk, pdflatex, booktabs, siunitx, longtable, natbib, and the standard graphics/math packages. The NeurIPS style is bundled, so building does not need internet access.

`main.pdf` contains four body pages, followed by references and an appendix. The body flows normally across pages, with no forced section-by-section page breaks. No margins or default font sizes have been reduced and no negative vertical spacing has been added. Changing the venue style or prose requires checking pagination again.

## Venue requirements (verified from the MATH-AI 2026 CFP)

Read from <https://mathai-2026.github.io/cfp/>:

- **Page limit:** 4 pages of content; 5 for camera-ready. References and appendices are
  unlimited and do **not** count. The current `main.pdf` is 4 body pages + 1 reference
  page + 3 appendix pages, which complies.
- **Template:** `\usepackage[dblblindworkshop]{neurips_2026}` for submission,
  `[dblblindworkshop, final]` for camera-ready. Template zip:
  <https://mathai-2026.github.io/files/mathai_neurips2026_template.zip>
- **Review:** double-blind. Keep the manuscript anonymised; the intro no longer uses
  first-person possessive when citing the preceding SageMath paper.
- **Deadline:** 6 September 2026, AoE.
- **Archival status:** non-archival; arXiv preprints do not count as prior publication.

**Outstanding:** `neurips_2026.sty` is not yet in this directory, so `main.tex` still
builds against the bundled `neurips_2025.sty` (`STYLE_SOURCE.txt` records its source).
The venue block at the top of `main.tex` marks the exact two lines to swap. The
"Preprint." footer comes from the 2025 stand-in and disappears under `dblblindworkshop`.

## Evidence and scope

All experimental quantities and case descriptions were taken from the user's verified fact sheet, retained verbatim in `SOURCE_REQUEST.md`. No additional experimental statistics were calculated for this paper. The supplied Wilson intervals are reproduced as given, including their rounding. No interval was invented for the planned-set coverage; that optional percentage is omitted. The estimate's cost allocation is given as dollar amounts, rather than treating a token-cost share as a binomial proportion.

`tables/outcomes.tex` is the lead provenance split. `tables/taxonomy.tex`, `tables/pooled.tex`, `tables/effort.tex`, and `tables/ledger.tex` provide the quantitative ledger. The appendix documents all ten decisive cases, limitations on correspondence, and both source hashes. The body explicitly distinguishes preliminary analyst classifications from an expert translation-fidelity audit. It does not treat LLM-positive labels as known-correct answers.

The local cascade implementation (`src/benchmark/judge_sympy_answers.py` in the parent repository) was read for framing. This drafting step made no new model calls, reran no experiment, and changed no runtime code. Independent certificate replay and defect reproduction refer to the earlier audit reported in the fact sheet.

## Figures

The body uses one figure, `figures/intermediate-flags.pdf`, with the supplied counts 84, 10, 29, and 13. Editable SVG and PNG sources are included, with `figures/build_flags.py`; it also generates the PDF directly, so no conversion is outstanding for this figure. Regenerate with Python and matplotlib, for example `MPLCONFIGDIR=/tmp/paper-mpl python figures/build_flags.py`.

The earlier HTML report has PNG/SVG figure sources, but its pooled `label-outcomes` figure is superseded and is deliberately not reused. The corrected provenance-split figure remains a specified open item in `OPEN_QUESTIONS.md`, as requested. If produced from PNG/SVG later, convert/export to `figures/provenance-outcomes.pdf` before including it. The existing table already reports the corrected split. A second figure is optional; the main body currently has one.

## Remaining placeholders

See `OPEN_QUESTIONS.md`: venue and authorship, expert correspondence review, no-hint control, corrected optional figure, reproducibility details, and final venue formatting. There are no unresolved inline `\todo{...}` calls in the manuscript; the macro is available for subsequent edits. The paper is a reviewable draft, not submission-ready.

## Claim provenance

Load-bearing evidence from the fact sheet: run size and interruption; cascade provenance and counts; supplied intervals; successful replay of ten certificates; preliminary taxonomy; concrete surrogate/normalization/counterexample cases; reproduced runtime defect and flag counts; UNKNOWN self-reports; recorded usage and estimated rates/costs.

Editorial framing in this draft: organizing the argument around certificate validity, statement fidelity, and label provenance; calling missing correspondences “unclosed reductions”; treating the cascade as a selection mechanism; and recommending semantic acceptance checks, paired controls, and cost per assessed full/partial result. The hypothesis that alternative presentations explain low decisive coverage in the judge-positive slice is explicitly untested. No novelty claim over the entire literature is made. The Related Work section positions this study against nine additional verified papers, including the preceding SageMath study; see `LITERATURE_SOURCES.md`.

## Article structure

1. Introduction: motivation, verification idea, and research questions.
2. Related Work: computational agents, autoformalization, and semantic evaluation.
3. Methodology: verification objective, end-to-end transfer/formalization/certification/evaluation, and experimental setup.
4. Preliminary Results: completion, label agreement, mathematical cases, runtime accounting, and effort.
5. Discussion and Limitations.
6. Conclusion.

The methodology was checked against `render_prompt` and `verify_certificate` in `src/benchmark/lean_pipeline.py`; no runtime changes or new experiment were performed.
